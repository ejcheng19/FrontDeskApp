﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FrontDeskApp
{
    public partial class FrontDeskApp : Form
    {
        public FrontDeskApp()
        {
            InitializeComponent();
            
        }

        private void btnCheckStorage_Click(object sender, EventArgs e)
        {
            CheckStorageForm formCS = new CheckStorageForm();
            formCS.Show();
        }
    }
}
