﻿
namespace FrontDeskApp
{
    partial class FrontDeskApp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.btnCheckStorage = new System.Windows.Forms.Button();
            this.btnAddInStorage = new System.Windows.Forms.Button();
            this.btnRetrieveInStorage = new System.Windows.Forms.Button();
            this.btnStorageTransaction = new System.Windows.Forms.Button();
            this.tableLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.btnStorageTransaction, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnCheckStorage, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.btnRetrieveInStorage, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.btnAddInStorage, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(651, 426);
            this.tableLayoutPanel1.TabIndex = 0;
            // 
            // btnCheckStorage
            // 
            this.btnCheckStorage.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.btnCheckStorage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCheckStorage.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCheckStorage.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckStorage.Location = new System.Drawing.Point(3, 3);
            this.btnCheckStorage.Name = "btnCheckStorage";
            this.btnCheckStorage.Size = new System.Drawing.Size(319, 207);
            this.btnCheckStorage.TabIndex = 0;
            this.btnCheckStorage.Text = "Check Storage";
            this.btnCheckStorage.UseVisualStyleBackColor = false;
            this.btnCheckStorage.Click += new System.EventHandler(this.btnCheckStorage_Click);
            // 
            // btnAddInStorage
            // 
            this.btnAddInStorage.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.btnAddInStorage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddInStorage.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddInStorage.Location = new System.Drawing.Point(328, 3);
            this.btnAddInStorage.Name = "btnAddInStorage";
            this.btnAddInStorage.Size = new System.Drawing.Size(319, 207);
            this.btnAddInStorage.TabIndex = 1;
            this.btnAddInStorage.Text = "Add in Storage";
            this.btnAddInStorage.UseVisualStyleBackColor = false;
            // 
            // btnRetrieveInStorage
            // 
            this.btnRetrieveInStorage.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRetrieveInStorage.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRetrieveInStorage.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRetrieveInStorage.Location = new System.Drawing.Point(3, 216);
            this.btnRetrieveInStorage.Name = "btnRetrieveInStorage";
            this.btnRetrieveInStorage.Size = new System.Drawing.Size(319, 207);
            this.btnRetrieveInStorage.TabIndex = 2;
            this.btnRetrieveInStorage.Text = "Retrieve in Storage";
            this.btnRetrieveInStorage.UseVisualStyleBackColor = false;
            // 
            // btnStorageTransaction
            // 
            this.btnStorageTransaction.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.btnStorageTransaction.BackColor = System.Drawing.SystemColors.Info;
            this.btnStorageTransaction.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnStorageTransaction.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStorageTransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStorageTransaction.Location = new System.Drawing.Point(328, 216);
            this.btnStorageTransaction.Name = "btnStorageTransaction";
            this.btnStorageTransaction.Size = new System.Drawing.Size(320, 207);
            this.btnStorageTransaction.TabIndex = 3;
            this.btnStorageTransaction.Text = "Storage Transaction";
            this.btnStorageTransaction.UseVisualStyleBackColor = false;
            // 
            // FrontDeskApp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(675, 450);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "FrontDeskApp";
            this.Text = "FrontDeskApp";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button btnStorageTransaction;
        private System.Windows.Forms.Button btnRetrieveInStorage;
        private System.Windows.Forms.Button btnAddInStorage;
        private System.Windows.Forms.Button btnCheckStorage;
    }
}