﻿
namespace FrontDeskApp
{
    partial class CheckStorageForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtboxOccupiedLA = new System.Windows.Forms.TextBox();
            this.txtboxOccupiedMA = new System.Windows.Forms.TextBox();
            this.txtboxOccupiedSA = new System.Windows.Forms.TextBox();
            this.txtboxAvailableLA = new System.Windows.Forms.TextBox();
            this.txtboxAvailableMA = new System.Windows.Forms.TextBox();
            this.txtbAvailableSA = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtboxOccupiedLA
            // 
            this.txtboxOccupiedLA.Location = new System.Drawing.Point(249, 98);
            this.txtboxOccupiedLA.Name = "txtboxOccupiedLA";
            this.txtboxOccupiedLA.ReadOnly = true;
            this.txtboxOccupiedLA.Size = new System.Drawing.Size(81, 20);
            this.txtboxOccupiedLA.TabIndex = 21;
            // 
            // txtboxOccupiedMA
            // 
            this.txtboxOccupiedMA.Location = new System.Drawing.Point(249, 67);
            this.txtboxOccupiedMA.Name = "txtboxOccupiedMA";
            this.txtboxOccupiedMA.ReadOnly = true;
            this.txtboxOccupiedMA.Size = new System.Drawing.Size(81, 20);
            this.txtboxOccupiedMA.TabIndex = 20;
            // 
            // txtboxOccupiedSA
            // 
            this.txtboxOccupiedSA.Location = new System.Drawing.Point(249, 35);
            this.txtboxOccupiedSA.Name = "txtboxOccupiedSA";
            this.txtboxOccupiedSA.ReadOnly = true;
            this.txtboxOccupiedSA.Size = new System.Drawing.Size(81, 20);
            this.txtboxOccupiedSA.TabIndex = 19;
            // 
            // txtboxAvailableLA
            // 
            this.txtboxAvailableLA.Location = new System.Drawing.Point(122, 98);
            this.txtboxAvailableLA.Name = "txtboxAvailableLA";
            this.txtboxAvailableLA.ReadOnly = true;
            this.txtboxAvailableLA.Size = new System.Drawing.Size(81, 20);
            this.txtboxAvailableLA.TabIndex = 18;
            // 
            // txtboxAvailableMA
            // 
            this.txtboxAvailableMA.Location = new System.Drawing.Point(122, 67);
            this.txtboxAvailableMA.Name = "txtboxAvailableMA";
            this.txtboxAvailableMA.ReadOnly = true;
            this.txtboxAvailableMA.Size = new System.Drawing.Size(81, 20);
            this.txtboxAvailableMA.TabIndex = 17;
            // 
            // txtbAvailableSA
            // 
            this.txtbAvailableSA.Location = new System.Drawing.Point(122, 35);
            this.txtbAvailableSA.Name = "txtbAvailableSA";
            this.txtbAvailableSA.ReadOnly = true;
            this.txtbAvailableSA.Size = new System.Drawing.Size(81, 20);
            this.txtbAvailableSA.TabIndex = 16;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(246, 9);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(87, 13);
            this.label5.TabIndex = 15;
            this.label5.Text = "Occupied Space";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(119, 9);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(84, 13);
            this.label4.TabIndex = 14;
            this.label4.Text = "Available Space";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 101);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(59, 13);
            this.label3.TabIndex = 13;
            this.label3.Text = "Large Area";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(9, 70);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 12;
            this.label2.Text = "Medium Area";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 38);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(57, 13);
            this.label1.TabIndex = 11;
            this.label1.Text = "Small Area";
            // 
            // CheckStorageForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.ClientSize = new System.Drawing.Size(350, 136);
            this.Controls.Add(this.txtboxOccupiedLA);
            this.Controls.Add(this.txtboxOccupiedMA);
            this.Controls.Add(this.txtboxOccupiedSA);
            this.Controls.Add(this.txtboxAvailableLA);
            this.Controls.Add(this.txtboxAvailableMA);
            this.Controls.Add(this.txtbAvailableSA);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "CheckStorageForm";
            this.Text = "CheckStorageForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

       
        private System.Windows.Forms.TextBox txtboxOccupiedLA;
        private System.Windows.Forms.TextBox txtboxOccupiedMA;
        private System.Windows.Forms.TextBox txtboxOccupiedSA;
        private System.Windows.Forms.TextBox txtboxAvailableLA;
        private System.Windows.Forms.TextBox txtboxAvailableMA;
        private System.Windows.Forms.TextBox txtbAvailableSA;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}